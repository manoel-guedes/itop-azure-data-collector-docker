<?php

/**
 * @since 1.3.0 N°6012
 */
class DoPostRequestService
{
	public function DoPostRequest($sUrl, $aData, $sOptionnalHeaders = null, &$aResponseHeaders = null, $aCurlOptions = []){
		return null;
	}
}
