<?php

class IOException extends Exception
{
}